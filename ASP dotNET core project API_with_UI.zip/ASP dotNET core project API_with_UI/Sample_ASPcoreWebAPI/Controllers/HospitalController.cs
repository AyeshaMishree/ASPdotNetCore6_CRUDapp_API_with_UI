﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using View_SampleHospitalAPI.Models;
using System.Net.Http;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Text;

namespace View_SampleHospitalAPI.Controllers
{
    public class HospitalController : Controller
    {
        private readonly string url = "https://localhost:7000/api/HospitalAPI/";
        private readonly HttpClient client;

        public HospitalController()
        {
            client = new HttpClient();
        }

        [HttpGet]
        public async Task<IActionResult> Index()
        {
            List<Hospital> hospitals = new List<Hospital>();

            try
            {
                HttpResponseMessage response = await client.GetAsync(url);
                if (response.IsSuccessStatusCode)
                {
                    string result = await response.Content.ReadAsStringAsync();
                    var data = JsonConvert.DeserializeObject<List<Hospital>>(result);
                    if (data != null)
                    {
                        hospitals = data;
                    }
                }
            }
            catch (HttpRequestException ex)
            {
                ViewBag.Error = "Error fetching data: " + ex.Message;
            }

            return View(hospitals);
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }
        //CREATE: Save New Hospital
        [HttpPost]
        public async Task<IActionResult> Create(Hospital hospital)
        {
            if (ModelState.IsValid)
            {
                string jsonData = JsonConvert.SerializeObject(hospital);
                StringContent content = new StringContent(jsonData, Encoding.UTF8, "application/json");

                HttpResponseMessage response = await client.PostAsync(url, content);

                if (response.IsSuccessStatusCode)
                {
                    return RedirectToAction(nameof(Index));
                }
            }
            return View(hospital);
        }

        // UPDATE: Display Edit Form
        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            Hospital hospital = new Hospital();

            HttpResponseMessage response = await client.GetAsync(url + id);
            if (response.IsSuccessStatusCode)
            {
                string result = await response.Content.ReadAsStringAsync();
                hospital = JsonConvert.DeserializeObject<Hospital>(result);
            }
            return View(hospital);
        }

        // UPDATE: Save Edited Data
        [HttpPost]
        public async Task<IActionResult> Edit(int id, Hospital hospital)
        {
            if (ModelState.IsValid)
            {
                string jsonData = JsonConvert.SerializeObject(hospital);
                StringContent content = new StringContent(jsonData, Encoding.UTF8, "application/json");

                HttpResponseMessage response = await client.PutAsync(url + id, content);
                if (response.IsSuccessStatusCode)
                {
                    return RedirectToAction(nameof(Index));
                }
            }
            return View(hospital);
        }

        //Display Delete Confirmation
        [HttpGet]
        public async Task<IActionResult> Delete(int id)
        {
            Hospital hospital = new Hospital();

            HttpResponseMessage response = await client.GetAsync(url + id);
            if (response.IsSuccessStatusCode)
            {
                string result = await response.Content.ReadAsStringAsync();
                hospital = JsonConvert.DeserializeObject<Hospital>(result);
            }
            return View(hospital);
        }

        //DELETE: Confirm & Delete Record
        [HttpPost, ActionName("Delete")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            HttpResponseMessage response = await client.DeleteAsync(url + id);
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction(nameof(Index));
            }
            return View();
        }
    }
}
