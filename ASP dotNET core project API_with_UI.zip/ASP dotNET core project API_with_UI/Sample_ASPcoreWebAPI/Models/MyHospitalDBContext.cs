﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace Sample_ASPcoreWebAPI.Models
{
    public partial class MyHospitalDBContext : DbContext
    {
        public MyHospitalDBContext()
        {
        }

        public MyHospitalDBContext(DbContextOptions<MyHospitalDBContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Hospital> Hospitals { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Hospital>(entity =>
            {
                entity.Property(e => e.HospitalId).HasColumnName("HospitalID");

                entity.Property(e => e.ContactNumber).HasMaxLength(50);

                entity.Property(e => e.HospitalName).HasMaxLength(255);

                entity.Property(e => e.Location).HasMaxLength(255);

                entity.Property(e => e.Specialization).HasMaxLength(255);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
