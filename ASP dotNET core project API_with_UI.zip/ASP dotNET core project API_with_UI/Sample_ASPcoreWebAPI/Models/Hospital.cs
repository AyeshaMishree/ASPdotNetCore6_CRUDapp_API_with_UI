﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Sample_ASPcoreWebAPI.Models
{
    public partial class Hospital
    {
        public int HospitalId { get; set; }
        [Required]
        public string HospitalName { get; set; } = null!;
        [Required]
        public string Location { get; set; } = null!;
        [Required]
        public int? EstablishedYear { get; set; }
        [Required]
        public string? ContactNumber { get; set; }
        [Required]
        public int? Capacity { get; set; }
        [Required]
        public string? Specialization { get; set; }
    }
}
