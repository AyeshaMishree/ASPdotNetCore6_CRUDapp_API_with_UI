﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Sample_ASPcoreWebAPI.Models;

namespace Sample_ASPcoreWebAPI.Controllers
{
    [Route("api/[controller]")] 
    [ApiController]
    public class HospitalAPIController : ControllerBase
    {
        private readonly MyHospitalDBContext context;
        public HospitalAPIController(MyHospitalDBContext contetx)
        { 
            this.context = contetx;
        }

        [HttpGet]
        public async Task<ActionResult<List<Hospital>>> GetHospitals()
        {
            var data = await context.Hospitals.ToListAsync();
            return Ok(data);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Hospital>> GetHospitalsById(int id)
        {
            var hospital = await context.Hospitals.FindAsync(id);
            if (hospital == null)
            {
                return NotFound();
            }
            return hospital;
        }

        [HttpPost]
        public async Task<ActionResult<Hospital>> CreateHospital(Hospital htl)
        {
            await context.Hospitals.AddAsync(htl);
            await context.SaveChangesAsync();
            return Ok(htl);

        }

        [HttpPut("{id}")]
        public async Task<ActionResult<Hospital>> UpdateHospital(int id, Hospital htl)
        {
            if (id != htl.HospitalId)
            {
                return BadRequest();
            }
            context.Entry(htl).State = EntityState.Modified;
            await context.SaveChangesAsync();
            return Ok(htl);
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult<Hospital>> DeleteHospital(int id)
        {
            var htl = await context.Hospitals.FindAsync(id);
            if (htl == null)
            {
                return NotFound();
            }
            context.Hospitals.Remove(htl);
            await context.SaveChangesAsync();
            return Ok(htl);
        }

    }
}
