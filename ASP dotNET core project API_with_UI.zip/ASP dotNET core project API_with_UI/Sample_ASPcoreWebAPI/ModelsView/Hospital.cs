﻿using System.ComponentModel.DataAnnotations;

namespace View_SampleHospitalAPI.Models
{
    public class Hospital
    {
        public int hospitalId { get; set; }
        [Required]
        public string hospitalName { get; set; }
        [Required]
        public string location { get; set; }
        [Required]
        public int establishedYear { get; set; }
        [Required]
        public string contactNumber { get; set; }
        [Required]
        public int capacity { get; set; }
        [Required]
        public string specialization { get; set; }
    }
}
